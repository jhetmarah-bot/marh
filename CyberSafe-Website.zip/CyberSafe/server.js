const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "cybersafe.db"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-deployment",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 4 }
}));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
  CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    summary TEXT NOT NULL,
    content TEXT NOT NULL,
    tip TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS quiz_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    choice_a TEXT NOT NULL,
    choice_b TEXT NOT NULL,
    choice_c TEXT NOT NULL,
    correct_answer TEXT NOT NULL,
    explanation TEXT NOT NULL
  );
`);

const lessonCount = db.prepare("SELECT COUNT(*) AS count FROM lessons").get().count;
if (lessonCount === 0) {
  const insert = db.prepare("INSERT INTO lessons (title, category, summary, content, tip) VALUES (?, ?, ?, ?, ?)");
  const seedLessons = [
    ["Spot the Phishing", "Scams", "Learn how fake messages try to trick you.", "Phishing messages pretend to come from trusted people or companies. They may say your account will close, you won a prize, or you must act immediately. Look closely at the sender and website address before doing anything.", "Pause. Check the sender. Open official apps or websites yourself instead of clicking unexpected links."],
    ["Build Better Passwords", "Passwords", "Create passwords that are difficult to guess.", "Use a long, unique password or passphrase for each account. Avoid names, birthdays, school names, and common patterns. A password manager can help you remember unique passwords.", "Never share your password. Turn on two-factor authentication when available."],
    ["Protect Your Privacy", "Privacy", "Think carefully before sharing personal details.", "Your full name, address, school ID, phone number, passwords, and live location can be misused. Review app permissions and privacy settings. Only share details when necessary and with trusted services.", "Before posting, ask yourself: would I be comfortable if a stranger saw this?"],
    ["Be Kind Online", "Digital Citizenship", "Use technology respectfully and responsibly.", "Do not bully, threaten, impersonate, or share someone else's private photos or information without permission. Save evidence of harmful behavior, block the account, and report it to a trusted adult or platform.", "Treat people online with the same respect you expect in person."],
    ["Secure Your Devices", "Device Safety", "Keep your phone, laptop, and apps safer.", "Install updates, use a screen lock, download apps from trusted stores, and avoid unknown files. Back up important schoolwork. Do not use public computers to save passwords.", "Updates help fix security weaknesses. Install them from official settings."]
  ];
  const seed = db.transaction((rows) => rows.forEach(row => insert.run(...row)));
  seed(seedLessons);
}

const questionCount = db.prepare("SELECT COUNT(*) AS count FROM quiz_questions").get().count;
if (questionCount === 0) {
  const insert = db.prepare(`INSERT INTO quiz_questions
    (question, choice_a, choice_b, choice_c, correct_answer, explanation)
    VALUES (?, ?, ?, ?, ?, ?)`);
  const questions = [
    ["A message says you won a prize and asks for your password. What should you do?", "Click quickly before it expires", "Avoid the link and verify through an official channel", "Send your password to confirm", "b", "Unexpected prizes that ask for passwords are a major warning sign. Never share your password."],
    ["Which is the best password habit?", "Use one password everywhere", "Use your birthday", "Use a long, unique password for each account", "c", "Unique passwords limit the damage if one account is compromised."],
    ["A stranger online asks for your home address. What is safest?", "Share it to be friendly", "Keep it private and tell a trusted adult if pressured", "Post it publicly", "b", "Personal information should not be shared with strangers."],
    ["You receive an unexpected attachment from an unknown sender. What should you do?", "Open it right away", "Forward it to friends", "Do not open it; verify the sender first", "c", "Unexpected attachments can contain harmful files."],
    ["What should you do if someone cyberbullies you?", "Reply with threats", "Save evidence, block/report them, and seek help", "Share their private information", "b", "Do not retaliate. Keep evidence and report the behavior."]
  ];
  const seed = db.transaction((rows) => rows.forEach(row => insert.run(...row)));
  seed(questions);
}

// Administrator table and first-run account.
db.exec(`CREATE TABLE IF NOT EXISTS admin_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);`);
// First-run demo account. Change this password before any public deployment.
const adminExists = db.prepare("SELECT id FROM admin_users WHERE username = ?").get("admin");
if (!adminExists) {
  db.prepare("INSERT INTO admin_users (username, password_hash) VALUES (?, ?)")
    .run("admin", bcrypt.hashSync("CyberSafe123!", 10));
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.status(401).json({ error: "Please sign in as an administrator." });
}

app.get("/api/lessons", (req, res) => {
  const lessons = db.prepare("SELECT id, title, category, summary, content, tip FROM lessons ORDER BY id DESC").all();
  res.json(lessons);
});

app.get("/api/quiz", (req, res) => {
  const questions = db.prepare("SELECT id, question, choice_a, choice_b, choice_c FROM quiz_questions ORDER BY id").all();
  res.json(questions);
});

app.post("/api/quiz/submit", (req, res) => {
  const answers = req.body.answers || {};
  const questions = db.prepare("SELECT id, correct_answer, explanation FROM quiz_questions ORDER BY id").all();
  let score = 0;
  const results = questions.map(q => {
    const chosen = String(answers[q.id] || "").toLowerCase();
    const correct = chosen === q.correct_answer;
    if (correct) score++;
    return { id: q.id, correct, explanation: q.explanation };
  });
  res.json({ score, total: questions.length, results, message: score === questions.length ? "Amazing! You're CyberSmart!" : "Good effort! Review the explanations and try again." });
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare("SELECT id, username, password_hash FROM admin_users WHERE username = ?").get(String(username || ""));
  if (!admin || !bcrypt.compareSync(String(password || ""), admin.password_hash)) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.adminId = admin.id;
  req.session.adminName = admin.username;
  res.json({ ok: true, username: admin.username });
});

app.get("/api/admin/me", (req, res) => {
  if (!req.session.adminId) return res.status(401).json({ signedIn: false });
  res.json({ signedIn: true, username: req.session.adminName });
});

app.post("/api/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.post("/api/admin/lessons", requireAdmin, (req, res) => {
  const { title, category, summary, content, tip } = req.body;
  if (![title, category, summary, content, tip].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete every lesson field." });
  }
  const result = db.prepare("INSERT INTO lessons (title, category, summary, content, tip) VALUES (?, ?, ?, ?, ?)")
    .run(title.trim(), category.trim(), summary.trim(), content.trim(), tip.trim());
  res.json({ id: result.lastInsertRowid, ok: true });
});

app.delete("/api/admin/lessons/:id", requireAdmin, (req, res) => {
  const result = db.prepare("DELETE FROM lessons WHERE id = ?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Lesson not found." });
  res.json({ ok: true });
});

app.post("/api/admin/quiz", requireAdmin, (req, res) => {
  const { question, choice_a, choice_b, choice_c, correct_answer, explanation } = req.body;
  if (![question, choice_a, choice_b, choice_c, correct_answer, explanation].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete every question field." });
  }
  if (!["a", "b", "c"].includes(correct_answer)) return res.status(400).json({ error: "Choose a valid correct answer." });
  const result = db.prepare(`INSERT INTO quiz_questions
    (question, choice_a, choice_b, choice_c, correct_answer, explanation) VALUES (?, ?, ?, ?, ?, ?)`)
    .run(question.trim(), choice_a.trim(), choice_b.trim(), choice_c.trim(), correct_answer, explanation.trim());
  res.json({ id: result.lastInsertRowid, ok: true });
});

app.get("/api/admin/quiz", requireAdmin, (req, res) => {
  res.json(db.prepare("SELECT * FROM quiz_questions ORDER BY id").all());
});

app.delete("/api/admin/quiz/:id", requireAdmin, (req, res) => {
  const result = db.prepare("DELETE FROM quiz_questions WHERE id = ?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Question not found." });
  res.json({ ok: true });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`CyberSafe is running at http://localhost:${PORT}`));
