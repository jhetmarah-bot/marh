# CyberSafe: Think Before You Click

A beginner-friendly BSIT cybersecurity awareness website for students. The design uses cute pastel colors and simple English/Taglish-friendly wording.

## Features

- Home page and responsive navigation
- Cybersecurity learning modules stored in SQLite
- "Scam or Safe?" interactive scenarios
- Browser-only sample password strength checker (does not send or save typed passwords)
- Quiz questions, server-checked scores, and explanations
- Online safety checklist saved in the current browser's localStorage
- Admin sign-in, add/delete lessons, and add/delete quiz questions
- SQLite database created automatically on first run

## Requirements

Install **Node.js LTS** from https://nodejs.org/. VS Code is recommended.

## Run the website

1. Extract the `CyberSafe.zip` folder.
2. Open the extracted `CyberSafe` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   ```

5. When installation finishes, run:

   ```bash
   npm start
   ```

6. Open this address in Chrome:

   `http://localhost:3000`

Keep the terminal running while you use the website. To stop the server, press `Ctrl + C` in the terminal.

## Demo administrator login

- Username: `admin`
- Password: `CyberSafe123!`

Scroll to the **Admin** section and sign in. You can add and delete learning lessons and quiz questions. This is a demo login for a school project. Do not deploy the demo credentials publicly.

## Database

On the first run, the server creates `cybersafe.db` in the project folder. It stores:
- Learning lessons
- Quiz questions
- Admin account password hash

The admin password is hashed using bcryptjs. The database file is excluded from version control by `.gitignore`.

## Technology used

- HTML: website structure
- CSS: pastel design and responsive layout
- JavaScript: interactivity, quiz UI, password feedback, and checklist
- Node.js + Express: backend/API routes
- SQLite via better-sqlite3: persistent content database
- express-session: administrator login session
- bcryptjs: password hash verification

## Important project limitations

This is a local school-project starter, not a production-ready security service. Before deploying publicly:
- Change the default admin password and session secret.
- Use HTTPS and secure cookie settings.
- Add login rate limiting, CSRF protection, and stronger session storage.
- Configure a persistent database location with backups.
- Consider a proper admin password-change page.
- Do not collect real passwords in the sample password checker.
- Quiz scores are shown to the student but are not saved to a personal account.

## Suggested demo steps

1. Open the home page and explain the purpose.
2. Open a lesson and show the safety tip.
3. Try one "Scam or Safe?" scenario.
4. Enter a made-up password in the checker.
5. Complete the quiz and show results.
6. Tick a few checklist items.
7. Sign in to Admin and add a sample lesson or quiz question.
8. Explain that lesson and quiz content is stored in the SQLite database.

## Simple defense explanation

"My project is called CyberSafe: Think Before You Click. It is a cybersecurity awareness website for students. I chose this topic because students use the internet every day and can encounter phishing, scams, weak passwords, and privacy risks.

The website includes short learning modules, a Scam or Safe activity, a password strength checker, an interactive quiz, and a personal safety checklist. It also has an admin panel where the administrator can add or delete lessons and quiz questions.

I used HTML and CSS for the layout and design, JavaScript for interactive features, Node.js and Express for the backend, and SQLite to store the lesson and quiz content. The goal is to make cybersecurity easier to understand and encourage students to practice safer online habits."

## Troubleshooting

- `npm` is not recognized: install Node.js LTS, close and reopen VS Code, then try again.
- Port 3000 is busy: run in Windows PowerShell with `$env:PORT=3001; npm start`, then open `http://localhost:3001`.
- Page won't load: confirm the terminal says `CyberSafe is running at http://localhost:3000`.
- Database reset for a fresh demo: stop the server, delete `cybersafe.db`, and run `npm start` again. This resets added content and the demo admin account.
