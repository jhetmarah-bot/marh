const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const escapeHTML = (value = "") => String(value).replace(/[&<>"']/g, char => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
}[char]));
const showToast = (message) => {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

// Mobile navigation
$("#menuToggle").addEventListener("click", () => $("#mainNav").classList.toggle("open"));
$$(".nav-link").forEach(link => link.addEventListener("click", () => {
  $("#mainNav").classList.remove("open");
  $$(".nav-link").forEach(item => item.classList.toggle("active", item === link));
}));

// Learning modules loaded from the SQLite database through the API.
const lessonIcons = { Scams: "🎣", Passwords: "🔑", Privacy: "🫧", "Digital Citizenship": "💗", "Device Safety": "💻" };
async function loadLessons() {
  const lessons = await api("/api/lessons");
  $("#lessonGrid").innerHTML = lessons.map(lesson => `
    <article class="lesson-card">
      <div class="lesson-icon">${lessonIcons[lesson.category] || "🌷"}</div>
      <span class="lesson-category">${escapeHTML(lesson.category)}</span>
      <h3>${escapeHTML(lesson.title)}</h3>
      <p>${escapeHTML(lesson.summary)}</p>
      <button class="lesson-expand" data-lesson="${lesson.id}" aria-expanded="false">Read lesson +</button>
      <div class="lesson-detail" id="lesson-detail-${lesson.id}" hidden>
        ${escapeHTML(lesson.content)}
        <div class="tip-box">💡 <strong>Quick tip:</strong> ${escapeHTML(lesson.tip)}</div>
      </div>
    </article>`).join("");
  $$(".lesson-expand").forEach(button => button.addEventListener("click", () => {
    const detail = $(`#lesson-detail-${button.dataset.lesson}`);
    const isOpen = !detail.hidden;
    detail.hidden = isOpen;
    button.textContent = isOpen ? "Read lesson +" : "Close lesson −";
    button.setAttribute("aria-expanded", String(!isOpen));
  }));
}

// Scam or Safe practice scenarios are fictional examples for learning.
const scenarios = [
  { avatar: "🎁", sender: "Unknown number", type: "Text message", message: "CONGRATS! You won ₱10,000. Click this unfamiliar link now and enter your account password to claim your prize.", scam: true, why: "The unexpected prize, urgency, unfamiliar link, and password request are warning signs. Don't click or share sensitive information." },
  { avatar: "🏦", sender: "Your bank app", type: "A message you did not expect", message: "Someone says your bank account will be locked today unless you send your one-time PIN (OTP) in this chat.", scam: true, why: "Never share an OTP or PIN. Contact your bank using its official app or number if you are worried." },
  { avatar: "📚", sender: "Your school portal", type: "You opened the official site yourself", message: "You type your school's known official website address yourself, sign in normally, and see a posted announcement about next week's exam schedule.", scam: false, why: "This situation sounds safer because you opened the known official site yourself. Still check the web address carefully and be alert for fake look-alike sites." },
  { avatar: "👭", sender: "Your classmate", type: "Message", message: "A classmate sends you a file you weren't expecting and says, 'Open this now, don't ask questions.'", scam: true, why: "Even if the sender is familiar, their account could be compromised. Verify with them through another channel before opening unexpected files." }
];
let scenarioIndex = 0;
function renderScenario() {
  const item = scenarios[scenarioIndex];
  $("#scenarioAvatar").textContent = item.avatar;
  $("#scenarioSender").textContent = item.sender;
  $("#scenarioType").textContent = item.type;
  $("#scenarioMessage").textContent = item.message;
  $("#scenarioCounter").textContent = `Scenario ${scenarioIndex + 1} of ${scenarios.length}`;
  $("#scenarioNumber").textContent = `${String(scenarioIndex + 1).padStart(2, "0")} / ${String(scenarios.length).padStart(2, "0")}`;
  $("#scenarioFeedback").hidden = true;
  $("#nextScenario").hidden = true;
  $("#scamButton").disabled = false;
  $("#safeButton").disabled = false;
}
function answerScenario(guessScam) {
  const item = scenarios[scenarioIndex];
  const feedback = $("#scenarioFeedback");
  const correct = guessScam === item.scam;
  feedback.className = `feedback-box ${correct ? "correct" : "incorrect"}`;
  feedback.innerHTML = `<strong>${correct ? "✨ You got it!" : "🌷 Good try — here's what to notice."}</strong><br>${escapeHTML(item.why)}`;
  feedback.hidden = false;
  $("#scamButton").disabled = true;
  $("#safeButton").disabled = true;
  $("#nextScenario").hidden = false;
  $("#nextScenario").textContent = scenarioIndex === scenarios.length - 1 ? "Start again ↻" : "Next scenario →";
}
$("#scamButton").addEventListener("click", () => answerScenario(true));
$("#safeButton").addEventListener("click", () => answerScenario(false));
$("#nextScenario").addEventListener("click", () => {
  scenarioIndex = (scenarioIndex + 1) % scenarios.length;
  renderScenario();
});
renderScenario();

// Password strength checker: nothing typed here is sent to the server or saved.
$("#passwordInput").addEventListener("input", () => {
  const value = $("#passwordInput").value;
  const checks = [
    value.length >= 12,
    /[a-z]/.test(value) && /[A-Z]/.test(value),
    /\d/.test(value),
    /[^A-Za-z0-9]/.test(value)
  ];
  const score = checks.filter(Boolean).length;
  $("#strengthBar").style.width = `${score * 25}%`;
  $("#strengthLabel").textContent = !value ? "Waiting for your sample..." : score <= 1 ? "Needs improvement" : score <= 2 ? "Getting stronger" : score === 3 ? "Pretty strong" : "Great variety!";
  $("#strengthBits").textContent = `${score} / 4 checks`;
  $("#passwordTips").innerHTML = [
    checks[0] ? "✓ 12 or more characters" : "Try using 12 or more characters.",
    checks[1] ? "✓ Includes uppercase and lowercase letters" : "Mix uppercase and lowercase letters.",
    checks[2] ? "✓ Includes a number" : "Consider adding a number.",
    checks[3] ? "✓ Includes a symbol" : "Consider adding a symbol.",
    "Use a unique password or passphrase for every account."
  ].map(tip => `<li>${escapeHTML(tip)}</li>`).join("");
});
$("#togglePassword").addEventListener("click", () => {
  const input = $("#passwordInput");
  input.type = input.type === "password" ? "text" : "password";
  $("#togglePassword").textContent = input.type === "password" ? "👁" : "🙈";
});

// Quiz: questions are loaded from SQLite. Answers are checked by the server.
let quizQuestions = [];
let quizIndex = 0;
let quizAnswers = {};
async function loadQuiz() {
  quizQuestions = await api("/api/quiz");
  quizIndex = 0;
  quizAnswers = {};
  renderQuiz();
}
function renderQuiz() {
  const container = $("#quizContainer");
  if (!quizQuestions.length) {
    container.innerHTML = '<p>No quiz questions yet. Ask the administrator to add some.</p>';
    return;
  }
  const q = quizQuestions[quizIndex];
  const options = [["a", q.choice_a], ["b", q.choice_b], ["c", q.choice_c]];
  container.innerHTML = `
    <div class="quiz-progress-row"><span>QUESTION ${quizIndex + 1} OF ${quizQuestions.length}</span><span>${Math.round((quizIndex / quizQuestions.length) * 100)}% completed</span></div>
    <div class="quiz-progress"><span style="width:${((quizIndex + 1) / quizQuestions.length) * 100}%"></span></div>
    <h3 class="quiz-question">${escapeHTML(q.question)}</h3>
    <div class="quiz-choices">${options.map(([letter, text]) => `<button class="quiz-choice ${quizAnswers[q.id] === letter ? "selected" : ""}" data-choice="${letter}"><span class="choice-letter">${letter.toUpperCase()}</span>${escapeHTML(text)}</button>`).join("")}</div>
    <div class="quiz-bottom"><small>${Object.keys(quizAnswers).length} of ${quizQuestions.length} answered</small><button class="btn btn-primary" id="quizNext">${quizIndex === quizQuestions.length - 1 ? "See my results →" : "Next question →"}</button></div>
  `;
  $$(".quiz-choice").forEach(button => button.addEventListener("click", () => {
    quizAnswers[q.id] = button.dataset.choice;
    renderQuiz();
  }));
  $("#quizNext").addEventListener("click", async () => {
    if (!quizAnswers[q.id]) return showToast("Choose an answer first 🌷");
    if (quizIndex < quizQuestions.length - 1) {
      quizIndex++;
      renderQuiz();
    } else {
      try { await submitQuiz(); } catch (error) { showToast(error.message); }
    }
  });
}
async function submitQuiz() {
  const result = await api("/api/quiz/submit", { method: "POST", body: JSON.stringify({ answers: quizAnswers }) });
  const missed = result.results.filter(r => !r.correct);
  $("#quizContainer").innerHTML = `
    <div class="quiz-result"><div class="result-emoji">${result.score === result.total ? "🏆" : result.score >= result.total / 2 ? "🌟" : "🌱"}</div>
      <h3>${escapeHTML(result.message)}</h3><div class="result-score">${result.score} / ${result.total}</div>
      <p class="result-feedback">${result.score === result.total ? "Perfect score! Keep practicing safe online habits." : "Review the notes below, then give it another try."}</p>
      <div class="result-list">${missed.length ? missed.map(r => {
        const question = quizQuestions.find(q => q.id === r.id);
        return `<div class="result-item"><strong>💡 ${escapeHTML(question ? question.question : "Review this question")}</strong>${escapeHTML(r.explanation)}</div>`;
      }).join("") : '<div class="result-item">✨ You answered every question correctly. Well done!</div>'}</div>
      <button class="btn btn-primary" id="retryQuiz">Try again ↻</button>
    </div>`;
  $("#retryQuiz").addEventListener("click", loadQuiz);
}

// Checklist uses localStorage on this device only.
const checklistHabits = [
  "I use unique passwords for my accounts.",
  "I never share my password or OTP.",
  "I check links before clicking.",
  "I keep my address and private details private.",
  "I update my phone, laptop, and apps.",
  "I block and report harmful online behavior."
];
const checklistKey = "cybersafe-checklist-v1";
function readChecklist() {
  try { return JSON.parse(localStorage.getItem(checklistKey) || "[]"); } catch { return []; }
}
function renderChecklist() {
  const checked = readChecklist();
  $("#checklistItems").innerHTML = checklistHabits.map((habit, index) => `
    <label class="checklist-item ${checked.includes(index) ? "checked" : ""}">
      <input type="checkbox" data-habit="${index}" ${checked.includes(index) ? "checked" : ""}>
      <span>${escapeHTML(habit)}</span>
    </label>`).join("");
  const count = checked.length;
  $("#checklistProgressText").textContent = `${count} of ${checklistHabits.length} habits`;
  $("#checklistProgressBar").style.width = `${(count / checklistHabits.length) * 100}%`;
  $("#checklistMessage").textContent = count === checklistHabits.length ? "Amazing! You're building great habits. 💗" : count >= 3 ? "You're making good progress. Keep going! 🌷" : "Let's build safer habits together. 💗";
  $$("#checklistItems input").forEach(input => input.addEventListener("change", () => {
    let values = readChecklist();
    const id = Number(input.dataset.habit);
    values = input.checked ? [...new Set([...values, id])] : values.filter(n => n !== id);
    localStorage.setItem(checklistKey, JSON.stringify(values));
    renderChecklist();
  }));
}
$("#resetChecklist").addEventListener("click", () => {
  localStorage.removeItem(checklistKey);
  renderChecklist();
});
renderChecklist();

// Admin area: login, lesson/question creation, and deletion.
let adminSignedIn = false;
function setAdminState(signedIn, username = "admin") {
  adminSignedIn = signedIn;
  $("#adminLogin").hidden = signedIn;
  $("#adminDashboard").hidden = !signedIn;
  $("#adminName").textContent = username;
}
async function checkAdminSession() {
  try {
    const data = await api("/api/admin/me");
    setAdminState(true, data.username);
    await refreshAdminLists();
  } catch { setAdminState(false); }
}
$("#adminLoginForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = $("#adminLoginMessage");
  message.textContent = "Signing in...";
  message.className = "form-message";
  try {
    const data = await api("/api/admin/login", { method: "POST", body: JSON.stringify({
      username: $("#adminUsername").value, password: $("#adminPassword").value
    })});
    setAdminState(true, data.username);
    $("#adminPassword").value = "";
    message.textContent = "";
    await refreshAdminLists();
    showToast("Welcome to the admin corner 🌷");
  } catch (error) {
    message.textContent = error.message;
  }
});
$("#adminLogout").addEventListener("click", async () => {
  await api("/api/admin/logout", { method: "POST", body: "{}" });
  setAdminState(false);
  showToast("You have signed out.");
});
$$(".admin-tab").forEach(tab => tab.addEventListener("click", () => {
  $$(".admin-tab").forEach(item => item.classList.toggle("active", item === tab));
  $$(".admin-tab-panel").forEach(panel => panel.hidden = panel.id !== tab.dataset.tab);
}));
async function refreshAdminLists() {
  if (!adminSignedIn) return;
  const [lessons, questions] = await Promise.all([api("/api/lessons"), api("/api/admin/quiz")]);
  $("#adminLessonList").innerHTML = lessons.map(item => `
    <div class="admin-list-item"><div><strong>${escapeHTML(item.title)}</strong><small>${escapeHTML(item.category)}</small></div><button class="delete-button" data-delete-lesson="${item.id}">Delete</button></div>`).join("");
  $("#adminQuestionList").innerHTML = questions.map(item => `
    <div class="admin-list-item"><div><strong>${escapeHTML(item.question)}</strong><small>Correct answer: ${escapeHTML(item.correct_answer.toUpperCase())}</small></div><button class="delete-button" data-delete-question="${item.id}">Delete</button></div>`).join("");
  $$("[data-delete-lesson]").forEach(button => button.addEventListener("click", async () => {
    if (!confirm("Delete this lesson?")) return;
    try { await api(`/api/admin/lessons/${button.dataset.deleteLesson}`, { method: "DELETE" }); await loadLessons(); await refreshAdminLists(); showToast("Lesson deleted."); }
    catch (error) { showToast(error.message); }
  }));
  $$("[data-delete-question]").forEach(button => button.addEventListener("click", async () => {
    if (!confirm("Delete this quiz question?")) return;
    try { await api(`/api/admin/quiz/${button.dataset.deleteQuestion}`, { method: "DELETE" }); await loadQuiz(); await refreshAdminLists(); showToast("Question deleted."); }
    catch (error) { showToast(error.message); }
  }));
}
$("#lessonForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  const message = $("#lessonFormMessage");
  try {
    await api("/api/admin/lessons", { method: "POST", body: JSON.stringify(data) });
    form.reset();
    message.textContent = "Lesson added successfully!";
    message.className = "form-message success";
    await loadLessons();
    await refreshAdminLists();
  } catch (error) { message.textContent = error.message; }
});
$("#questionForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  const message = $("#questionFormMessage");
  try {
    await api("/api/admin/quiz", { method: "POST", body: JSON.stringify(data) });
    form.reset();
    message.textContent = "Question added successfully!";
    message.className = "form-message success";
    await loadQuiz();
    await refreshAdminLists();
  } catch (error) { message.textContent = error.message; }
});

Promise.all([loadLessons(), loadQuiz(), checkAdminSession()]).catch(error => {
  console.error(error);
  showToast("Couldn't load the website data. Make sure the server is running.");
});
